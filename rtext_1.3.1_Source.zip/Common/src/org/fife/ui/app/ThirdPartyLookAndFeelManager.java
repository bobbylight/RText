/*
 * 03/11/2005
 *
 * ThirdPartyLookAndFeelManager.java - Class that can read an XML file
 * specifying all 3rd party Look and Feels available to a GUIApplication.
 * Copyright (C) 2005 Robert Futrell
 * robert_futrell at users.sourceforge.net
 * http://fifesoft.com
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package org.fife.ui.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import org.fife.ui.app.ExtendedLookAndFeelInfo;


/**
 * NOTE: Specifying LookAndFeels in this XML file is done at your own risk!
 * If a LookAndFeel throws an Exception on the EDT, for any reason (needs
 * special configuration not handled by this LAF manager, requires a newer
 * JRE version than is specified in the XML, etc.), it can hose the
 * <code>GUIApplication</code> and keep it from running!<p>
 *
 * A class capable of reading an XML file specifying 3rd party Look and Feel
 * JAR files, and returning an array of information about the Look and Feels,
 * so your <code>GUIApplication</code> can use them.<p>
 *
 * The XML file read should have the following format:<p>
 * <pre>
 *   &lt;?xml version="1.0" encoding="UTF-8" ?&gt;
 *   &lt;ThirdPartyLookAndFeels&gt;
 *      &lt;LookAndFeel name="name" class="class" jars="jar"/&gt;
 *      &lt;LookAndFeel name="name" class="class" jars="jar" minJavaVersion="1.6"/&gt;
 *      ... other LookAndFeel tags if desired ...
 *   &lt;/ThirdPartyLookAndFeels&gt;
 * </pre>
 *
 * where <code>name</code> is the name of the Look and Feel (as appears in
 * RText's menu), <code>class</code> is the main Look and Feel class, such as
 * <code>org.fife.plaf.OfficeXP.OfficeXPLookAndFeel</code>, and
 * <code>jars</code> is the path(s) to the JAR file(s) containing the Look and
 * Feel, relative to the install location of the specified
 * <code>GUIApplication</code>.  The <code>minJavaVersion</code> attribute is
 * optional, and specifies the minimum Java version the JRE must be for the
 * application to offer this LookAndFeel as a choice.  This should be a double
 * value, such as "1.5", "1.6", etc.
 *
 * @author Robert Futrell
 * @version 1.0
 */
public class ThirdPartyLookAndFeelManager {

	/**
	 * The root directory of the application.
	 */
	private String appRoot;

	private List lnfInfo;
	private URLClassLoader lafLoader;

	private static final String CLASS				= "class";
	private static final String JARS				= "jars";
	private static final String LOOK_AND_FEEL		= "LookAndFeel";
	private static final String MIN_JAVA_VERSION	= "minJavaVersion";
	private static final String NAME				= "name";


	/**
	 * Constructor.
	 */
	public ThirdPartyLookAndFeelManager(String appRoot) {

		this.appRoot = appRoot;
		URL[] urls = null;

		lnfInfo = load3rdPartyLookAndFeelInfo("lnfs/lookandfeels.xml");

		try {
			int count = lnfInfo==null ? 0 : lnfInfo.size();
			// 3rd party Look and Feel jars?  Add them to classpath.
			// NOTE:  The lines of code below MUST be in the order they're
			// in or stuff breaks for some reason; I'm not sure why...
			if (count>0) {
				List lnfJarUrlList = new ArrayList();
				for (Iterator i=lnfInfo.iterator(); i.hasNext(); ) {
					ExtendedLookAndFeelInfo info =
									(ExtendedLookAndFeelInfo)i.next();
					urls = info.getURLs(appRoot);
					for (int j=0; j<urls.length; j++) {
						if (!lnfJarUrlList.contains(urls[j])) {
							lnfJarUrlList.add(urls[j]);
						}
					}
				}
				urls = (URL[])lnfJarUrlList.toArray(new URL[0]);
			}
		} catch (RuntimeException re) { // FindBugs
			throw re;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (urls==null) {
			urls = new URL[0];
		}

		// Specifying a parent ClassLoader other than the default hoses some
		// LAFs, such as Substance.
		lafLoader = new URLClassLoader(urls);//this.getClass().getClassLoader());

	}


	/**
	 * Returns an array of information on the JAR files containing 3rd party
	 * Look and Feels.  These jars were dynamically loaded from an XML file
	 * relative to the root directory you gave this manager instance.
	 *
	 * @return An array of URLs for JAR files containing Look and Feels.
	 */
	public ExtendedLookAndFeelInfo[] get3rdPartyLookAndFeelInfo() {
		if (lnfInfo==null) {
			return new ExtendedLookAndFeelInfo[0];
		}
		ExtendedLookAndFeelInfo[] array =
					new ExtendedLookAndFeelInfo[lnfInfo.size()];
		return (ExtendedLookAndFeelInfo[])lnfInfo.toArray(array);
	}


	public ClassLoader getLAFClassLoader() {
		return lafLoader;
	}


	/**
	 * Returns an array with each element representing a 3rd party Look and
	 * Feel available to your GUI application.
	 *
	 * @param xmlFile The XML file specifying the 3rd party Look and Feels.
	 * @return A list of {@link ExtendedLookAndFeelInfo}s.
	 */
	private List load3rdPartyLookAndFeelInfo(String xmlFile) {

		File file = new File(appRoot, xmlFile);
		if (!file.isFile()) {
			return null;
		}

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		Document doc = null;
		try {
			db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new BufferedReader(
					new InputStreamReader(new FileInputStream(file), "UTF-8")));
			is.setEncoding("UTF-8");
			doc = db.parse(is);
		} catch (RuntimeException re) { // FindBugs
			throw re;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		// Traverse the XML tree.
		ArrayList lafInfo = new ArrayList(1);
		try {
			loadFromXML(doc.getDocumentElement(), lafInfo);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		return lafInfo;

	}


	/**
	 * Used in parsing the XML file containing the 3rd party look and feels.
	 *
	 * @param node The root node of the parsed XML document.
	 * @param lafInfo An array list of <code>ExtendedLookAndFeelInfo</code>s.
	 * @throws IOException If an error occurs while parsing the XML.
	 */
	private static void loadFromXML(Element root, ArrayList lafInfo)
										throws IOException {

		if (root==null) {
			throw new IOException("XML error:  node==null!");
		}

		NodeList children = root.getChildNodes();
		for (int i=0; i<children.getLength(); i++) {

			Node child = children.item(i);
			if (child.getNodeType()==Node.ELEMENT_NODE) {

				String elemName = child.getNodeName();

				// Might be a Look and Feel declaration.
				if (LOOK_AND_FEEL.equals(elemName)) {
	
					// Shouldn't have any children.
					NodeList childNodes = child.getChildNodes();
					if (childNodes!=null && childNodes.getLength()>0) {
						throw new IOException("XML error:  LookAndFeel " +
							"tags shouldn't have children!");
					}
					NamedNodeMap attributes = child.getAttributes();
					if (attributes==null || attributes.getLength()<3) {
						throw new IOException("XML error: LookAndFeel " +
							"tags should have three attributes!");
					}
					String name = null;
					String className = null;
					String jars = null;
					double minVersion = 0;
					for (int j=0; j<attributes.getLength(); j++) {
						Node node2 = attributes.item(j);
						String attr = node2.getNodeName();
						if (NAME.equals(attr)) {
							name = node2.getNodeValue();
						}
						else if (CLASS.equals(attr)) {
							className = node2.getNodeValue();
						}
						else if (JARS.equals(attr)) {
							jars = node2.getNodeValue();
						}
						else if (MIN_JAVA_VERSION.equals(attr)) {
							try {
								minVersion = Double.parseDouble(node2.getNodeValue());
							} catch (NumberFormatException nfe) {
								nfe.printStackTrace();
							}
						}
						else {
							throw new IOException("XML error: unknown " +
								"attribute: '" + attr + "'");
						}
					}
					if (name==null || className==null || jars==null) {
						throw new IOException("XML error: LookAndFeel " +
							"must have attributes 'name', 'class' and " +
							"'jar'.");
					}
					boolean add = true;
					if (minVersion>0) {
						String javaSpecVersion = System.getProperty("java.specification.version");
						try {
							double javaSpecVersionVal = Double.parseDouble(javaSpecVersion);
							add = javaSpecVersionVal >= minVersion;
						} catch (NumberFormatException nfe) {
							nfe.printStackTrace();
						}
					}
					if (add) {
						lafInfo.add(new ExtendedLookAndFeelInfo(name,
														className, jars));
					}
				}

				// Anything else is an error.
				else {
					throw new IOException("XML error:  Unknown element " +
						"node: " + elemName);
				}

			}

		}

	}


}